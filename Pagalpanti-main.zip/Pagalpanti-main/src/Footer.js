import React from 'react'

export default function Footer() {
  return (
   <>
<div className='container-fluid mt-5  p-4 text-center' style={{fontSize:'.8rem' , backgroundColor:'rgb(18 25 42)'}} > © Copyright 2024 - Developed by Nirbhay Kumar. All right reserved.</div>

   </>
  )
}
//212529  color code

